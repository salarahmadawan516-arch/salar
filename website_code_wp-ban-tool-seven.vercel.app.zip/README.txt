# WEBSITE CODE EXTRACTIONS REPORT 

Website: https://wp-ban-tool-seven.vercel.app
EXTRACTION DATE: 3554883.198591367

## Summary:
- HTML FILES: 1
- CSS FILES: 0
- INLINE CSS BLOCKS: 1
- JAVASCRIPT FILES: 0
- INLINE JAVASCRIPT BLOCKS: 1
- API ENDPOINTS FOUND: 0
- IMAGES FOUND: 0

## Files Structure:
- index.html (Main HTML file)
- css/ (All CSS files)
- js/ (All JavaScript files)
- api_endpoints.txt (List of found API endpoints)

## Note:
This extraction includes all publicly accessible code from the website.
Some dynamic content loaded via AJAX may not be included.
